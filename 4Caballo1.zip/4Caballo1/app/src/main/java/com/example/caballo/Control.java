package com.example.caballo;

public class Control {
public static boolean viewfinal;
public static boolean menuscore;
}
